# Chatroom

A simple Chatroom built in C programming language. 
The program has two files - <b>server.c</b> and <b>client.c</b>. The program is built uses multithreading for handling multiple clients.
<br/> <br/>
Just simply run the Makefile using this command.
<br>
$ make Makefile compile
<br/>
<br/>
$./server [PORT]
<br/>
$./client [PORT]
<br/>
$./client [PORT]
<br/>
$./client [PORT]
<br/>
$./client [PORT]
<br/>
10 clients at most 